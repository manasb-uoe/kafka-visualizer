import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {AppComponent} from "./app/app.component";
import {BrowserXhr, HttpModule} from "@angular/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {Ng2BootstrapModule} from "ngx-bootstrap";
import "./rxjs-extensions";
import {BrokersComponent} from "./app/components/brokers.component";
import {NavbarComponent} from "./app/components/navbar.component";
import {TopicsListComponent} from "./app/components/topics-list.component";
import {ApiService} from "./app/services/api.service";
import {TopicsDataComponent} from "./app/components/topics-data.component";
import {NgProgressCustomBrowserXhr, NgProgressModule} from "ng2-progressbar";
import {CollapsibleItemComponent} from "./app/components/collapsible-item.component";
import {PrettyJsonModule, SafeJsonPipe} from "angular2-prettyjson";
import {JsonPipe} from "@angular/common";
import {TopicConsumersComponent} from "./app/components/topic-consumers.component";
import {AppBodyComponent} from "./app/components/app-body.component";

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        Ng2BootstrapModule.forRoot(),
        NgProgressModule,
        PrettyJsonModule
    ],
    declarations: [
        AppComponent,
        NavbarComponent,
        AppBodyComponent,
        BrokersComponent,
        TopicsListComponent,
        TopicsDataComponent,
        TopicConsumersComponent,
        CollapsibleItemComponent
    ],
    providers: [
        ApiService,
        { provide: BrowserXhr, useClass: NgProgressCustomBrowserXhr },
        { provide: JsonPipe, useClass: SafeJsonPipe }
    ],
    bootstrap: [AppComponent],
})
export class AppModule {
}
