export class KafkaBroker {
    public hostname: string;
    public port: number;
}