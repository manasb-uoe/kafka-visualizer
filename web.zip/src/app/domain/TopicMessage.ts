export class TopicMessage {
    public topic: string;
    public partition: number;
    public offset: 0;
    public timestamp: number;
    public value: string;
}