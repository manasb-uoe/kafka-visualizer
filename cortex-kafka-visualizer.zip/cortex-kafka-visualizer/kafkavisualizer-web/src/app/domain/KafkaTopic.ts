export class KafkaTopic {
    public name: string;
    public numPartitions: number;
    public isSelected: boolean;
}