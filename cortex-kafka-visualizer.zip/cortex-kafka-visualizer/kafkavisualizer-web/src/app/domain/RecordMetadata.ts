export class RecordMetadata {
  public constructor(public offset: number, public partition: number) {
  }
}
