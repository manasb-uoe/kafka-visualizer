export class KafkaBroker {
  public id: number;
  public hostname: string;
  public port: number;
}
