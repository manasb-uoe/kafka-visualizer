import {InjectionToken} from '@angular/core';
export let JQ_TOKEN = new InjectionToken<string>('jQuery');