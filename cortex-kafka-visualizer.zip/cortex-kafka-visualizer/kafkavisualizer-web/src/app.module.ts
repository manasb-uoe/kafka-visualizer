import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {AppComponent} from "./app/app.component";
import {HttpModule} from "@angular/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import "./rxjs-extensions";
import {BrokersComponent} from "./app/components/brokers.component";
import {NavbarComponent} from "./app/components/navbar.component";
import {TopicsListComponent} from "./app/components/topics-list.component";
import {ApiService} from "./app/services/api.service";
import {TopicsDataComponent} from "./app/components/topics-data.component";
import {CollapsibleItemComponent} from "./app/components/collapsible-item.component";
import {PrettyJsonModule, SafeJsonPipe} from "angular2-prettyjson";
import {JsonPipe} from "@angular/common";
import {TopicConsumersComponent} from "./app/components/topic-consumers.component";
import {AppBodyComponent} from "./app/components/app-body.component";
import {Tabs} from "./app/components/tabs.component";
import {JQ_TOKEN} from "./app/services/jquery.service";
import {TopicPublisherComponent} from "./app/components/topic-publisher.component";

declare let $: Object;

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        PrettyJsonModule
    ],
    declarations: [
        AppComponent,
        NavbarComponent,
        AppBodyComponent,
        BrokersComponent,
        TopicsListComponent,
        TopicsDataComponent,
        TopicConsumersComponent,
        CollapsibleItemComponent,
        TopicPublisherComponent,
        Tabs.TabsComponent,
        Tabs.TabComponent
    ],
    providers: [
        ApiService,
        { provide: JsonPipe, useClass: SafeJsonPipe },
        { provide: JQ_TOKEN, useValue: $ }
    ],
    bootstrap: [AppComponent],
})
export class AppModule {
}
