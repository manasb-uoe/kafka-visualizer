'use strict';

const path = require('path');
const webpack = require('webpack');
const merge = require('webpack-merge');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const UglifyJsPlugin = require('webpack/lib/optimize/UglifyJsPlugin');
const LoaderOptionsPlugin = require('webpack/lib/LoaderOptionsPlugin');
const StringReplacePlugin = require("string-replace-webpack-plugin");

// Fix LESS issues with dark/night theming
const lessThemeFixLoader = () => {
    return StringReplacePlugin.replace({
        replacements: [
            {
                pattern: /\nhtml\.(dark|light) html\.(dark|light)/g,
                replacement: (match, p1, p2) => `\nhtml.${p1}`
            },
            {
                pattern: /\n(.*)html\.(dark|light)\s(.*)/g,
                replacement: (match, p1, p2, p3) => `\nhtml.${p2} ${p1} ${p3}`
            }
        ]
    })
};

const nodeEnv = process.env.NODE_ENV || 'development';

const commonConfig = {
    entry: {
        'polyfills': './src/polyfills.ts',
        'vendor': './src/vendor.ts',
        'main': './src/main.ts',
        'styles': './src/styles/app.less'
    },

    resolve: {
        modules: [path.resolve('./src'), 'node_modules'],
        extensions: ['.ts', '.js', '.json', '.less', '.css', '.html'],
    },

    module: {
        rules: [
            {
                test: /\.ts$/,
                use: [{loader: 'tslint-loader', options: {typeCheck: true}}],
                exclude: /node_modules/,
                enforce: "pre"
            },
            {
                test: /\.html$/,
                use: [{loader: 'htmlhint-loader', options: {configFile: 'htmlhint.json'}}],
                exclude: /node_modules/,
                enforce: "pre"
            },
            {
                test: /\.ts$/,
                use: [{loader: 'awesome-typescript-loader'}, {loader: 'angular2-template-loader'}],
                exclude: /node_modules/
            },
            {
                test: /\.html$/,
                use: [{
                    loader: 'html-loader', options: {
                        minimize: true,
                        removeAttributeQuotes: false,
                        caseSensitive: true,
                        customAttrSurround: [[/#/, /(?:)/], [/\*/, /(?:)/], [/\[?\(?/, /(?:)/]],
                        customAttrAssign: [/\)?]?=/],
                        root: path.resolve('src')
                    }
                }]
            },
            {
                test: /\.(png|jpg|jpeg|svg|gif|woff|woff2|ttf|eot)(\?v=\d+\.\d+\.\d+)?$/,
                use: 'file-loader'
            }
        ]
    },

    plugins: [
        new webpack.ProvidePlugin({
            $: 'jquery',
            jQuery: 'jquery',
            'window.jQuery': 'jquery',
            Popper: ['popper.js', 'default'],
            // In case you imported plugins individually, you must also require them here:
            Util: "exports-loader?Util!bootstrap/js/dist/util",
            Dropdown: "exports-loader?Dropdown!bootstrap/js/dist/dropdown",
        }),
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: JSON.stringify(nodeEnv)
            }
        }),
        new webpack.optimize.CommonsChunkPlugin({
            name: ['vendor', 'polyfills']
        }),
        new CopyWebpackPlugin([{
            from: __dirname + '/src/images',
            to: 'images'
        }]),
        new webpack.ContextReplacementPlugin(
            // The (\\|\/) piece accounts for path separators in *nix and Windows
            /angular(\\|\/)core(\\|\/)@angular/,
            path.resolve(__dirname, 'src'),
            {} // a map of your routes
        ),
        new HtmlWebpackPlugin({
            template: 'src/index.html',
            chunksSortMode: 'dependency'
        })
    ]
};

const devConfig = {
    devtool: 'inline-source-map',
    output: {
        filename: '[name].bundle.js',
        publicPath: '/'
    },

    module: {
        rules: [
            {
                test: /\.less$/,
                include: path.resolve(__dirname, 'src/styles'),
                use: ['style-loader', 'css-loader', lessThemeFixLoader(), 'less-loader']
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            }
        ]
    },

    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new ExtractTextPlugin({filename: '[name].bundle.css'})
    ],

    devServer: {
        contentBase: 'src',
        compress: true,
        historyApiFallback: true,
        inline: true,
        host: '0.0.0.0',
        disableHostCheck: true,
        port: 4000,
        stats: 'minimal',
        overlay: true,
        hot: true,
        proxy: {
            '/api/**': {
                target: {
                    port: 8080
                },
                secure: false
            },
            '/actuator/**': {
                target: {
                    port: 8080
                },
                secure: false
            },
        }
    }
};

const prodConfig = {
    devtool: 'source-map',

    output: {
        path: path.join(__dirname, '/target/classes/static'),
        filename: '[name].[hash].bundle.js',
        publicPath: '/'
    },

    module: {
        rules: [
            {
                test: /\.less$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: [
                        'css-loader',
                        lessThemeFixLoader(),
                        {loader: 'less-loader', options: {compress: false}}
                    ]
                })
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: ['css-loader']
                })
            }
        ]
    },

    plugins: [
        new ExtractTextPlugin({filename: '[name].[hash].css'}),
        new LoaderOptionsPlugin({debug: false, minmize: false}),
        new webpack.NoEmitOnErrorsPlugin(),
        new UglifyJsPlugin({
            beautify: false,
            comments: false,
            compress: {
                screw_ie8: true,
                warnings: false,
                keep_fnames: true
            },
            mangle: false,
            sourceMap: true
        })
    ]

};

let config;
switch (nodeEnv) {
    case 'production':
        console.info('NODE_ENV: production');
        config = merge(commonConfig, prodConfig);
        break;
    default:
        console.info('NODE_ENV: development');
        config = merge(commonConfig, devConfig);
        break;
}

module.exports = config;
