# Kafkavisualizer

## Local Mode
### Start REST Server:
Run `kafkavisualizer-rest/com.jpmorgan.am.KafkavisualizerRestApplication` from your IDE. Application starts on port 8080
### Start Node Web Server:
Run `yarn start` from `kafkavisualizer-web` directory. Application starts on port 9000

## Production Mode
### Run `mvn package` from project root

Executable JAR: `kafkavisualizer-app/target/kafkavisualizer-<version>.jar`