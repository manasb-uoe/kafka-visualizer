package com.jpmorgan.am.domain.kafka;

import java.util.UUID;

public class KafkaStatics {
    public static String GROUP_ID = "CORTEX_KAFKA_VISUALIZER_" + UUID.randomUUID().toString();
}
