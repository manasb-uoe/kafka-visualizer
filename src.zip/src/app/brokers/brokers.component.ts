import {Component} from "@angular/core";

@Component({
    selector: "brokers",
    template: `<h3>Brokers</h3>`
})
export class BrokersComponent {}
