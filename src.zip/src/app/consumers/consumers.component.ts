import {Component} from "@angular/core";

@Component({
    selector: "consumers",
    template: `<h3>Consumers</h3>`
})
export class ConsumersComponent {}