import {RouterModule, Routes} from "@angular/router";
import {BrokersComponent} from "./app/brokers/brokers.component";
import {TopicsComponent} from "./app/topics/topics.component";
import {ConsumersComponent} from "./app/consumers/consumers.component";

const routes: Routes = [
    {path: "", redirectTo: "/topics", pathMatch: "full"},
    {path: "topics", component: TopicsComponent},
    {path: "consumers", component: ConsumersComponent},
    {path: "brokers", component: BrokersComponent},
];

export const routing = RouterModule.forRoot(routes, {useHash: true});
