import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {AppComponent} from "./app/app.component";
import {routing} from "./app.routing";
import {BrowserXhr, HttpModule} from "@angular/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {Ng2BootstrapModule} from "ngx-bootstrap";
import "./rxjs-extensions";
import {BrokersComponent} from "./app/brokers/brokers.component";
import {TopicsComponent} from "./app/topics/topics.component";
import {NavbarComponent} from "./app/navbar/navbar.component";
import {ConsumersComponent} from "./app/consumers/consumers.component";
import {TopicsListComponent} from "./app/topics/topics-list.component";
import {ApiService} from "./app/topics/api.service";
import {TopicsDataComponent} from "./app/topics/topics-data.component";
import {NgProgressCustomBrowserXhr, NgProgressModule} from "ng2-progressbar";
import {CollapsibleItemComponent} from "./app/topics/collapsible-item.component";
import {PrettyJsonModule, SafeJsonPipe} from "angular2-prettyjson";
import {JsonPipe} from "@angular/common";
import {TopicConsumersComponent} from "./app/topics/topic-consumers.component";

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        routing,
        Ng2BootstrapModule.forRoot(),
        NgProgressModule,
        PrettyJsonModule
    ],
    declarations: [
        AppComponent,
        NavbarComponent,
        TopicsComponent,
        ConsumersComponent,
        BrokersComponent,
        TopicsListComponent,
        TopicsDataComponent,
        TopicConsumersComponent,
        CollapsibleItemComponent
    ],
    providers: [
        ApiService,
        { provide: BrowserXhr, useClass: NgProgressCustomBrowserXhr },
        { provide: JsonPipe, useClass: SafeJsonPipe }
    ],
    bootstrap: [AppComponent],
})
export class AppModule {
}
