package com.jpmorgan.am.kafkavisualizer.domain.zookeeper;

public class ZookeeperNode {
    public String hostname;
    public int port;
}
