package com.jpmorgan.am.kafkavisualizer.domain.kafka;

public class KafkaStatics {
    public static String GROUP_ID = "VisualizerGroupId";
}
