package com.jpmorgan.am.kafkavisualizer.services;

import com.google.common.collect.ImmutableList;
import com.jpmorgan.am.kafkavisualizer.domain.kafka.KafkaStatics;
import com.jpmorgan.am.kafkavisualizer.domain.kafka.KafkaTopic;
import com.jpmorgan.am.sharedcore.util.DefectException;
import com.jpmorgan.am.sharedcore.util.collectors.ImmutableListCollector;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

public class KafkaConsumerWrapper implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(KafkaConsumerWrapper.class);

    private final KafkaConsumer<String, String> kafkaConsumer;
    private final ImmutableList<KafkaTopic> topics;
    private final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
    private final AtomicReference<Boolean> isSubscribed = new AtomicReference<>(false);

    public KafkaConsumerWrapper(String kafkaServersString, ImmutableList<KafkaTopic> topics) {
        this.topics = topics;

        Properties properties = new Properties();
        properties.put("bootstrap.servers", kafkaServersString);
        properties.put("group.id", KafkaStatics.GROUP_ID);
        properties.put("enable.auto.commit", "true");

        kafkaConsumer = new KafkaConsumer<>(properties, new StringDeserializer(), new StringDeserializer());
    }

    public void subscribe(Consumer<ConsumerRecord<String, String>> recordConsumer) {
        if (isSubscribed.get()) {
            throw new DefectException("Can only subscribe once!");
        }

        isSubscribed.set(true);

        subscribeFromBeginning();

        executorService.scheduleAtFixedRate(() -> {
            ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
            records.forEach(recordConsumer);
        }, 0, 1000, TimeUnit.MILLISECONDS);
    }

    private void subscribeFromBeginning() {
        ImmutableList<String> topicNames = topics.stream().map(topic -> topic.name).collect(ImmutableListCollector.newImmutableListCollector());
        kafkaConsumer.subscribe(topicNames);
        kafkaConsumer.poll(0); // subscribe is lazy, and therefore we need to poll before seeking
        kafkaConsumer.seekToBeginning(ImmutableList.of());
    }

    @Override
    public void close() throws Exception {
        kafkaConsumer.close();
    }
}
